"""REST API магазину: товари та замовлення у форматі JSON.

Усі адреси починаються з /api. API не використовує сесію (на відміну від кошика
на сайті): кожен запит містить усю потрібну інформацію (принцип stateless).
Дані беремо з тієї самої бази, що й сайт, через функції з models.py.
"""
import sqlite3

from flask import Blueprint, jsonify, request, url_for

import models
from .shop import MAX_QUANTITY

api_bp = Blueprint('api', __name__, url_prefix='/api')


# ------------------------------------------------------------ допоміжні функції

def error(message, status):
    """Єдиний формат помилки для всього API: {"error": "..."} + код статусу."""
    return jsonify({'error': message}), status


def is_number(value):
    """Число, але не True/False (у Python bool — підклас int)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def read_product_json():
    """Читає й перевіряє JSON товару. Повертає (дані, повідомлення про помилку)."""
    data = request.get_json(silent=True)  # None, якщо тіло запиту не є JSON
    if not isinstance(data, dict):
        return None, 'Тіло запиту має бути JSON-об\'єктом.'

    name = data.get('name')
    price = data.get('price')
    image = data.get('image', '')

    if not isinstance(name, str) or not name.strip():
        return None, 'Поле name обов\'язкове й має бути непорожнім рядком.'
    if not is_number(price) or price < 0:
        return None, 'Поле price обов\'язкове й має бути числом не менше 0.'
    if not isinstance(image, str):
        return None, 'Поле image має бути рядком.'

    return {'name': name.strip(), 'price': round(price, 2), 'image': image.strip()}, None


def read_order_json():
    """Читає й перевіряє JSON замовлення. Повертає (email, address, кошик, помилка).

    Очікуваний формат:
    {"email": "...", "address": "...", "items": [{"product_id": 1, "quantity": 2}]}
    Кошик повертається у тому самому вигляді, що й на сайті: {id товару: кількість}.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return None, None, None, 'Тіло запиту має бути JSON-об\'єктом.'

    email = data.get('email')
    address = data.get('address')
    items = data.get('items')

    if not isinstance(email, str) or '@' not in email:
        return None, None, None, 'Поле email обов\'язкове й має бути коректною адресою.'
    if not isinstance(address, str) or not address.strip():
        return None, None, None, 'Поле address обов\'язкове й має бути непорожнім рядком.'
    if not isinstance(items, list) or not items:
        return None, None, None, 'Поле items має бути непорожнім списком.'

    cart = {}
    for item in items:
        if not isinstance(item, dict) or not is_int(item.get('product_id')) or not is_int(item.get('quantity')):
            return None, None, None, 'Кожен елемент items має містити цілі числа product_id і quantity.'
        if not 1 <= item['quantity'] <= MAX_QUANTITY:
            return None, None, None, f'quantity має бути від 1 до {MAX_QUANTITY}.'
        # Якщо товар вказано двічі, кількості додаються
        cart[item['product_id']] = min(cart.get(item['product_id'], 0) + item['quantity'], MAX_QUANTITY)

    return email.strip(), address.strip(), cart, None


def order_to_dict(order, items=None):
    """Перетворює рядок замовлення (і за потреби його позиції) на словник для JSON."""
    result = dict(order)
    if items is not None:
        result['items'] = [dict(item) for item in items]
    return result


# ------------------------------------------------------------------- товари

@api_bp.route('/products', methods=['GET'])
def get_products():
    return jsonify([dict(row) for row in models.get_products()]), 200


@api_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = models.get_product(product_id)
    if product is None:
        return error('Товар не знайдено', 404)
    return jsonify(dict(product)), 200


@api_bp.route('/products', methods=['POST'])
def create_product():
    data, message = read_product_json()
    if message:
        return error(message, 400)

    product_id = models.add_product(**data)
    response = jsonify({'id': product_id, **data})
    # 201 Created + заголовок Location з адресою нового ресурсу
    return response, 201, {'Location': url_for('api.get_product', product_id=product_id)}


@api_bp.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    """Повне оновлення: потрібні всі обов'язкові поля (name, price)."""
    if models.get_product(product_id) is None:
        return error('Товар не знайдено', 404)

    data, message = read_product_json()
    if message:
        return error(message, 400)

    models.update_product(product_id, **data)
    return jsonify({'id': product_id, **data}), 200


@api_bp.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    if models.get_product(product_id) is None:
        return error('Товар не знайдено', 404)
    try:
        models.delete_product(product_id)
    except sqlite3.IntegrityError:
        # Спрацював зовнішній ключ (ON DELETE RESTRICT): товар є в замовленнях
        return error('Не можна видалити товар, який є в замовленнях', 409)
    return '', 204


# --------------------------------------------------------------- замовлення

@api_bp.route('/orders', methods=['GET'])
def get_orders():
    return jsonify([order_to_dict(order) for order in models.get_orders()]), 200


@api_bp.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    order, items = models.get_order_details(order_id)
    if order is None:
        return error('Замовлення не знайдено', 404)
    return jsonify(order_to_dict(order, items)), 200


@api_bp.route('/orders', methods=['POST'])
def create_order():
    email, address, cart, message = read_order_json()
    if message:
        return error(message, 400)

    # Усі товари із замовлення мають існувати в базі
    existing = {product['id'] for product in models.get_products_by_ids(cart.keys())}
    missing = sorted(set(cart) - existing)
    if missing:
        return error(f'Товару з id {missing[0]} не існує', 400)

    order_id = models.create_order(email, address, cart)
    order, items = models.get_order_details(order_id)
    return (
        jsonify(order_to_dict(order, items)),
        201,
        {'Location': url_for('api.get_order', order_id=order_id)},
    )


@api_bp.route('/orders/<int:order_id>', methods=['PATCH'])
def update_order(order_id):
    """Часткове оновлення замовлення: змінюється лише статус."""
    order, _ = models.get_order_details(order_id)
    if order is None:
        return error('Замовлення не знайдено', 404)

    data = request.get_json(silent=True)
    status = data.get('status') if isinstance(data, dict) else None
    if status not in models.ORDER_STATUSES:
        return error('Поле status має бути одним із: ' + ', '.join(models.ORDER_STATUSES), 400)

    models.update_order_status(order_id, status)
    order, items = models.get_order_details(order_id)
    return jsonify(order_to_dict(order, items)), 200
