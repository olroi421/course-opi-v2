from .admin import admin_bp
from .feedback import feedback_bp
from .shop import shop_bp
from .api import api_bp
