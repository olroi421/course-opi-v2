import os
from datetime import datetime

from flask import Flask, jsonify, render_template, request, session

import models
from routes import admin_bp, api_bp, feedback_bp, shop_bp

app = Flask(__name__)
# Шлях до файлу БД зберігаємо в конфігурації (поруч з app.py, незалежно від поточної теки)
app.config['DATABASE'] = os.environ.get('DATABASE', os.path.join(app.root_path, 'db.sqlite'))
# Ключ підписує сесію (кошик). Для реального сайту задайте власний через змінну середовища SECRET_KEY.
app.secret_key = os.environ.get('SECRET_KEY', 'dev-only-change-me')

# JSON-відповіді: кирилиця без \uXXXX і ключі в тому порядку, в якому ми їх записали
app.json.ensure_ascii = False
app.json.sort_keys = False

# Закриваємо з'єднання з БД після кожного запиту
app.teardown_appcontext(models.close_db)

# Створюємо таблиці під час запуску (якщо їх ще немає)
with app.app_context():
    models.init_db()

app.register_blueprint(feedback_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(shop_bp)
app.register_blueprint(api_bp)


@app.errorhandler(404)
@app.errorhandler(405)
@app.errorhandler(500)
def handle_error(error):
    """Для адрес /api/... повертає помилку у форматі JSON, для сайту — звичайну HTML-сторінку."""
    if request.path.startswith('/api/'):
        messages = {
            404: 'Ресурс не знайдено',
            405: 'Метод не дозволений для цієї адреси',
            500: 'Внутрішня помилка сервера',
        }
        return jsonify({'error': messages[error.code]}), error.code
    return error


@app.template_filter('money')
def money(value):
    """Форматує суму: 1299.9 -> '1299.90 грн'."""
    return f'{value:.2f} грн'


@app.context_processor
def inject_globals():
    """Змінні, доступні в усіх шаблонах."""
    return {
        'current_year': datetime.now().year,
        'cart_count': sum(session.get('cart', {}).values()),
    }


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/about')
def about():
    return render_template('about.html')


if __name__ == '__main__':
    app.run(debug=True)
