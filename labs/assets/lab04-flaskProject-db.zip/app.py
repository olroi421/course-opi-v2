import os
from datetime import datetime

from flask import Flask, render_template, session

import models
from routes import admin_bp, feedback_bp, shop_bp

app = Flask(__name__)
# Шлях до файлу БД зберігаємо в конфігурації (поруч з app.py, незалежно від поточної теки)
app.config['DATABASE'] = os.environ.get('DATABASE', os.path.join(app.root_path, 'db.sqlite'))
# Ключ підписує сесію (кошик). Для реального сайту задайте власний через змінну середовища SECRET_KEY.
app.secret_key = os.environ.get('SECRET_KEY', 'dev-only-change-me')

# Закриваємо з'єднання з БД після кожного запиту
app.teardown_appcontext(models.close_db)

# Створюємо таблиці під час запуску (якщо їх ще немає)
with app.app_context():
    models.init_db()

app.register_blueprint(feedback_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(shop_bp)


@app.template_filter('money')
def money(value):
    """Форматує суму: 1299.9 -> '1299.90 грн'."""
    return f'{value:.2f} грн'


@app.context_processor
def inject_globals():
    """Змінні, доступні в усіх шаблонах."""
    return {
        'current_year': datetime.now().year,
        'cart_count': sum(session.get('cart', {}).values()),
    }


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/about')
def about():
    return render_template('about.html')


if __name__ == '__main__':
    app.run(debug=True)
