"""Наповнює базу тестовими даними (товари, одне замовлення, один відгук).
Запуск: python seed_data.py. Якщо в таблиці товарів уже є записи — нічого не робить.
"""
from app import app
import models

PRODUCTS = [
    ('Футболка', 299.99),
    ('Джинси', 799.99),
    ('Кросівки', 1299.99),
    ('Куртка', 1599.99),
    ('Шапка', 199.99),
    ('Шкарпетки', 49.99),
    ('Рюкзак', 699.99),
    ('Годинник', 2499.99),
]


def seed():
    models.init_db()
    if models.get_products():
        print('У таблиці товарів уже є дані — пропускаю.')
        return

    for number, (name, price) in enumerate(PRODUCTS, start=1):
        # Зображення-заглушка; для кожного товару своя (за номером)
        models.add_product(name, price, f'https://picsum.photos/seed/shop{number}/400/300')

    first, second = models.get_products()[:2]
    models.create_order('student@example.com', 'м. Луцьк, вул. Володимирська, 1', {first['id']: 2, second['id']: 1})
    models.add_feedback('Тестовий користувач', 'user@example.com', 'Чудовий магазин, дякую!')
    print('Тестові дані додано до бази даних.')


if __name__ == '__main__':
    with app.app_context():
        seed()
